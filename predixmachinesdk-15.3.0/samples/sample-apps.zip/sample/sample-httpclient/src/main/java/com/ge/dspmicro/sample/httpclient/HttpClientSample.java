/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.sample.httpclient;

import java.net.URI;
import java.util.concurrent.TimeUnit;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import aQute.bnd.annotation.component.Deactivate;
import aQute.bnd.annotation.component.Reference;

import com.ge.dspmicro.httpclient.api.HttpResponseWrapper;
import com.ge.dspmicro.httpclient.api.IHttpClient;
import com.ge.dspmicro.httpclient.api.IHttpClientFactory;

/**
 * 
 * @author Predix Machine Sample
 */

// @Component is use to register this component as Service in the container.

@SuppressWarnings("nls")
@Component(name = HttpClientSample.SERVICE_PID)
public class HttpClientSample

{
    /** service id */
    protected final static String SERVICE_PID       = "com.ge.dspmicro.sample.httpclient";            //$NON-NLS-1$

    /** Create logger to report errors, warning massages, and info messages (runtime Statistics) */
    protected static Logger       _logger           = LoggerFactory.getLogger(HttpClientSample.class);

    private IHttpClient           httpClientService;
    // info for getting props from the http client bundle

    // connection information.
    private final static String   SAMPLE_RESTSERVER = "https://localhost:8443/httpclient/sample/v1";  //$NON-NLS-1$

    /**
     * The activate method is called when bundle is started.
     * 
     * @param ctx Component Context.
     */
    @Activate
    public void activate(ComponentContext ctx)
    {

        // use the logger service for debugging purpose
        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Starting sample " + ctx.getBundleContext().getBundle().getSymbolicName());
        }

        // The REST server may not started up completely yet. Best practice is to do these in a thread since you don't know how long it will take for the URL to
        // become active.
        Runnable runner = new Runnable()
        {
            @Override
            public void run()
            {
                int count = 20;
                for (int ii = 0; ii < count; ii++)
                {
                    try
                    {
                        // sending a "/httpclient/sample/v1/get" request to the public httpclient test server
                        URI uri = new URI(SAMPLE_RESTSERVER + "/get");
                        // HttpGet get = new HttpGet(uri);

                        HttpResponseWrapper response = getHttpClientService().get(uri);

                        if ( response.getStatusCode() == 200 )
                        {
                            _logger.info("HttpclientSample GET success:" + response.getContent().trim());
                            return;
                        }

                        if ( ii < count - 1 )
                        {
                            _logger.warn("HttpclientSample failed, not able to connect to sample public server. Status Code: "
                                    + response.getStatusCode());

                            // The REST server may not be available yet since this is a timing of startup.
                            TimeUnit.SECONDS.sleep(1);
                        }
                        else
                        {
                            _logger.error("HttpclientSample failed, not able to connect to sample public server. Status Code: "
                                    + response.getStatusCode());
                        }
                    }
                    catch (Exception ee)
                    {
                        _logger.error("HttpclientSample failed.", ee);
                    }
                }
            }
        };

        new Thread(runner).start();
    }

    /**
     * This method is called when the bundle is stopped.
     * 
     * @param ctx Component Context
     */
    @Deactivate
    public void deactivate(ComponentContext ctx)
    {
        // Put your clean up code here when container is shutting down

        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Stopped sample for " + ctx.getBundleContext().getBundle().getSymbolicName()); //$NON-NLS-1$
        }
    }

    /**
     * @return the httpClientService
     */
    public IHttpClient getHttpClientService()
    {
        return this.httpClientService;
    }

    /**
     * Use Dependency injection of IHttpClient service
     * 
     * @param httpClientFactory Instance of HttpClientFactory. Use this to create a new private instance of IHttpClient service.
     * 
     * @param httpClientService the httpClientService to set
     */
    @SuppressWarnings("deprecation")
    @Reference
    public void setHttpClientService(IHttpClientFactory httpClientFactory)
    {
        /* When modifying the IHttpClient, it will affect all other instances since the client uses a shared thread pool
        Therefore when modifying (configuring HTTPS as an example), the best practice is to use the factory
        and create your own private instance of IHttpClient instead of injecting the standard IHttpClient . */
        this.httpClientService = httpClientFactory.createHttpClient();

        /*
         * WARNING: In production, do not use this configuration. ALLOW_ALL_HOSTNAME_VERIFIER is not secure because it skips
         * hostname verification. Instead, use:
         * this.httpClientService.setAllowSSL(IHttpClient.sslType.ALLOW_DEFAULT_CERTS,
         *      SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
         */
        this.httpClientService.setAllowSSL(IHttpClient.sslType.ALLOW_DEFAULT_CERTS,
                SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
    }

    /**
     * clear the Dependency injection of IHttpClient
     * 
     * @param httpClientService the httpClientService to unset
     * 
     */
    @SuppressWarnings("hiding")
    public void unsetHttpClientService(IHttpClient httpClientService)
    {
        this.httpClientService = null;
    }

    /**
     * @param restServer Not used.
     */
    @Reference
    public void setHttpClientSampleRestServer(IHttpClientSampleRestServer restServer)
    {
        // Empty method. This is to wait for RestServer to start first.
    }
}
