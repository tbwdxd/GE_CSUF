

HTTP Client Sample - Shows how to use the HTTP Client service to make a rest call 

This sample requires HTTP enabled, copy the system/security files, i.e.
system/security/com.ge.dspmicro.securityadmin.cfg 

If you choose to not use code to modify the configurations, you can modify the
com.ge.dspmicro.httpclient.cfg file for the environment settings.
	File location: <Predix-Machine>/etc