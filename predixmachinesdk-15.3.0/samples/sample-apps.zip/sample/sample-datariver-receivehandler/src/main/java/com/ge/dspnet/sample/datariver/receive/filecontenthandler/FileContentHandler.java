/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspnet.sample.datariver.receive.filecontenthandler;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.CheckedOutputStream;
import java.util.zip.Checksum;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.dspnet.datariver.common.idl.DataRiverContent;
import com.ge.dspnet.datariver.receive.api.IContentHandler;
import com.ge.dspnet.datariver.receive.api.IDataRiverResponse;

/**
 * ContentHandler process' data received from DataSend service
 */
public class FileContentHandler
        implements IContentHandler
{
    private static Logger       _logger                  = LoggerFactory.getLogger(FileContentHandler.class);
    
    private static final String CHECKSUM_DISPOSITION_KEY = "CRC32"; //$NON-NLS-1$
    private static final String FILENAME_DISPOSITION_KEY = "name";  //$NON-NLS-1$
    private static final String TMP_EXTENSION            = "!tmp";  //$NON-NLS-1$

    private String              saveToLocation;
    private long                totalBytes;
    private CheckedOutputStream outputStream;
    private File                fileToSave;

    private boolean             active                   = true;   // whether or not this handler is still active

    /**
     * @param saveToLocation Location to save the content received
     */
    public FileContentHandler(String saveToLocation)
    {
        this.saveToLocation = saveToLocation;
    }

    /**
     * Handle content received
     * 
     * @param content Data Received for processing
     */
    @Override
    public synchronized void handleContent(IDataRiverResponse content)
    {
        // Verify if Handler is active
        if ( !this.active )
        {
            _logger.error("Transfer no longer active"); //$NON-NLS-1$
            return;
        }

        // Get content from packet received from Data River Receive Service
        DataRiverContent dataContent = content.getContent();

        // will close when transfer is complete
        try
        {
            // Initialize stream if its the first chunk of data.
            if ( this.outputStream == null )
            {
                String filename = getDispositionValue(dataContent.contentDisposition, FILENAME_DISPOSITION_KEY);
                this.outputStream = initStream(filename);
            }

            // Collect all data for the content
            // Once Data Has been received, one last chunk with no content of contentLength -1 is received to indicate it is the last chunk
            if ( dataContent.contentLength > 0 )
            {
                this.outputStream.write(dataContent.content.toArrayByte(null), 0, dataContent.contentLength);
                this.totalBytes += dataContent.contentLength;
            }
            else
            {
                // Last chunk with no content
                this.active = false;

                // If content is a file, it contains a CRC32 Checksum value in the disposition
                if ( runChecksum(this.outputStream.getChecksum(), dataContent) )
                {
                    content.success();
                }
                else
                {
                    content.fail();
                }

                // Close Stream
                if ( this.outputStream != null )
                {
                    this.outputStream.close();
                    this.outputStream = null;
                }

                removeTmpExtension(this.fileToSave);
                
                _logger.info("Total Bytes Received " + this.totalBytes); //$NON-NLS-1$
            }
        }
        catch (Exception e)
        {
            this.active = false;
            content.fail();
        }
    }

    private void removeTmpExtension(File tmpFile)
    {
        String filename = tmpFile.getAbsolutePath();
        if ( !filename.endsWith(TMP_EXTENSION) )
        {
            return;
        }
        Pattern tmpMatcher = Pattern.compile("(.+)\\." + TMP_EXTENSION + "$"); //$NON-NLS-1$ //$NON-NLS-2$
        Matcher m = tmpMatcher.matcher(filename);

        if ( !m.matches() || m.groupCount() == 0 )
        {
            return;
        }
        String newFileName = m.group(1);
        try
        {
            Path tmpFilePath = tmpFile.toPath();
            Files.move(tmpFile.toPath(), tmpFilePath.resolveSibling(newFileName));
        }
        catch (IOException ee)
        {
            _logger.warn("Unable to remove file extension"); //$NON-NLS-1$
        }

    }

    // verifies checksum of content with passed in checksum
    private boolean runChecksum(Checksum checksum, DataRiverContent content)
    {
        String passedChecksumStr = getDispositionValue(content.contentDisposition, CHECKSUM_DISPOSITION_KEY);
        if ( passedChecksumStr == null || checksum.getValue() != Long.valueOf(passedChecksumStr) )
        {
            return false;
        }
        return true;
    }

    // content disposition is semicolon separated key/value pairs. Retrieves a particular key
    // out of the string containing all of the key/value pairs. Returns null if the key was not found
    private String getDispositionValue(String contentDisposition, String key)
    {
        String[] dispositions = contentDisposition.split("[;|]"); //$NON-NLS-1$
        if ( dispositions.length == 0 )
        {
            return null; // key was not found
        }
        String checksumEntry = null;
        for (String disposition : dispositions)
        {
            if ( disposition.startsWith(key) )
            {
                checksumEntry = disposition;
                break;
            }
        }
        if ( checksumEntry == null )
        {
            return null; // key was not found
        }
        return checksumEntry.split("=")[1]; //$NON-NLS-1$
    }

    /**
     * Initialize Stream when there is new content.
     * 
     * @throws Exception if error occurs opening file or stream
     */
    private CheckedOutputStream initStream(String contentName)
            throws Exception
    {
        this.totalBytes = 0;

        File parentFolderFile = new File(this.saveToLocation);
        String filePath = this.saveToLocation + File.separator + contentName;

        File file = new File(filePath);
        // Check that the path is not outside of the container
        if ( !file.getParentFile().getCanonicalPath().startsWith(parentFolderFile.getCanonicalPath()) )
        {
            throw new Exception("Invalid Path"); //$NON-NLS-1$
        }
        File parent = file.getParentFile();
        if ( !parent.exists() )
        {
            parent.mkdirs();
        }

        // avoid overwriting files with the same name
        int conflicCount = 0;
        File fileTmp = new File(file.getAbsoluteFile() + "." + TMP_EXTENSION); //$NON-NLS-1$
        while (file.exists() || fileTmp.exists())
        {
            String tempFilePath = resolveNameConflict(filePath, ++conflicCount);
            file = new File(tempFilePath);
            fileTmp = new File(tempFilePath + "." + TMP_EXTENSION); //$NON-NLS-1$
        }
        this.fileToSave = fileTmp;
        OutputStream os = new BufferedOutputStream(new FileOutputStream(fileTmp));
        return new CheckedOutputStream(os, new CRC32());
    }

    /**
     * Resolves the name of a file if there is one already with the given name.
     * 
     * @param fileName Given name for data stream
     * @param conflicCount
     * @return The name of a file with no conficts in given directory.
     */
    private String resolveNameConflict(String fileName, int conflicCount)
    {
        int dotIndex = fileName.lastIndexOf('.');                                                       // folder/one.txt -> returns index of "."
        int fileSeparatorIndex = fileName.lastIndexOf(File.separator);                                  // folder.name/filename -> returns index of "/"

        // Normal case. Where file contains extension.
        if ( dotIndex >= 0 && dotIndex > fileSeparatorIndex )
        {
            return String
                    .format("%s[%s]%s", fileName.substring(0, dotIndex), String.valueOf(conflicCount), fileName.substring(dotIndex)); //$NON-NLS-1$
        }

        // For Edge Case where, File name does not contain "."
        return String.format("%s[%s]", fileName, String.valueOf(conflicCount)); //$NON-NLS-1$
    }

    @Override
    public void cleanupFailedTransfer()
    {
        this.active = false;

        try
        {
            if ( this.outputStream != null )
            {
                this.outputStream.close();
            }
        }
        catch (IOException e)
        {
            _logger.error("Error closing the output stream of the failed transfer.", e); //$NON-NLS-1$
        }
    }
}
