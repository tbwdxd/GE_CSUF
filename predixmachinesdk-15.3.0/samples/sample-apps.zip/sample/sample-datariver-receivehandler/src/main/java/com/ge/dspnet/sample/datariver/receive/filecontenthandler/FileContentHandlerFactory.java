/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspnet.sample.datariver.receive.filecontenthandler;

import java.io.File;

import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import aQute.bnd.annotation.component.Deactivate;

import com.ge.dspnet.datariver.common.util.DataRiverCommon;
import com.ge.dspnet.datariver.receive.api.IContentHandler;
import com.ge.dspnet.datariver.receive.api.IContentHandlerFactory;

/**
 * Content handler factory Sample for content handlers
 */
@Component(immediate = true, name = FileContentHandlerFactory.SERVICE_PID, provide = IContentHandlerFactory.class)
public class FileContentHandlerFactory
        implements IContentHandlerFactory
{
    /**
     * Service PID
     */
    public static final String  SERVICE_PID              = "com.ge.dspnet.sample.datariver.receive.handler";        //$NON-NLS-1$

    private static final String CUSTOM_SAVE_TO_LOCATION  = "newDownloads";                                             //$NON-NLS-1$

    /**
     * Create logger to report errors, warning massages, and info messages (runtime Statistics)
     */
    protected static Logger     _logger                  = LoggerFactory.getLogger(FileContentHandlerFactory.class);
    
    /**
     * The activate method is called when bundle is started.
     * 
     * @param ctx Component Context
     */
    @Activate
    public void activate(ComponentContext ctx)
    {
        // use the logger service for debugging purpose
        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Starting sample " + ctx.getBundleContext().getBundle().getSymbolicName()); //$NON-NLS-1$
        }        
    }

    /**
     * This method is called when the bundle is stopped.
     * 
     * @param ctx Component Context
     */
    @Deactivate
    public void deactivate(ComponentContext ctx)
    {
        // use the logger service for debugging purpose
        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("File Content Handler Factory service stopped"); //$NON-NLS-1$
        }
    }

    @Override
    public IContentHandler createContentHandler()
    {        
        String saveLocation = DataRiverCommon.TRANSFER_DIRECTORY + File.separator + CUSTOM_SAVE_TO_LOCATION;
        _logger.info("Creating content handler that saves files to " + saveLocation); //$NON-NLS-1$
        return new FileContentHandler(saveLocation);
    }
}
