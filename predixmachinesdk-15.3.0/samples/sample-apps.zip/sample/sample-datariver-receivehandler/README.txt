

Data River Receive Content Handler sample -- demonstrates how to setup custom handling of content received by the DataRiver Receive service.

This custom handler saves the content to <Predix-Machine>/appdata/transfers/newDownloads instead of the default location.


NOTE: this samples requires RTI APIs. This means these items should be pushed to a local artifactory so that these can be resolved:

        <dependency>
            <groupId>com.rti</groupId>
            <artifactId>${com.rti.artifactId}</artifactId>
            <version>${com.rti.nddsjava}</version>
            <scope>provided</scope>
        </dependency>

        
The jar can be download from RTI or extracted out of the umfcore-dds-XXX.jar

For example:
mvn install:install-file -DgroupId=com.rti \
-DartifactId=nddsjava \
-Dversion=5.1.0.47 \
-Dfile=nddsjava.jar \
-Dpackaging=jar \
-DgeneratePom=true
