

Management Sample - Shows how to use the SAML server configured in STS Client service to authenticate users in the system.


To use this sample:

1. This Sample Requires Configuration of keystores environment - Please follow the instructions in the Sample STS Client since this sample reads those
properties.

NOTE: this samples requires Prosyst APIs. This means these items should be pushed to a local artifactory so that these can be resolved:

        <dependency>
            <groupId>com.prosyst</groupId>
            <artifactId>com.prosyst.mbs.core.api</artifactId>
            <version>${com.prosyst.mbs.core.api.version}</version>
        </dependency>
        <!-- ProSyst com.prosyst.mbs.services.useradmin -->
        <dependency>
            <groupId>com.prosyst</groupId>
            <artifactId>com.prosyst.mbs.util.api</artifactId>
            <version>${com.prosyst.version}</version>
        </dependency>

2. Remove the existing user authentication bundle com.ge.dspmicro.management-impl-{version}.jar from being loaded.
    Comment out the loading of this bundle in the system/init/dspmicro.ini file:
    <!--
         <bundle>
            <name>../../system/jars/solution/com.ge.dspmicro.management-impl-{version}.jar </name>
        </bundle>
    -->
    
3.  Modify the solution.ini file by adding a <bundle> tag for each sample in the folowing format
        <bundle>
            <name>../../system/jars/solution/com.ge.dspmicro.sample-management-{version}.jar </name>
        </bundle>

4. Optionally remove the web console user administration tab. This tab allows for re-setting passwords and creating new users.
    When clicking these options, an error of "not supported" is returned to the user. 
    
    Comment out the loading of the bundle in the osgi/bin/vms/boot.ini file:
    <!--
        <bundle>
            <name>fw.web.console.ua-{version}.jar</name>
        </bundle>
    -->
      
5. You must also have an STS server running. 
    a. Using the PredixSDK you can generate a container with the STS Server feature.
    b. In the STSLoginImpl class there is a URL STS_SERVER_URL constant. Change this to point to where you are hosting 
       the container with STS Server.
    c. Export the dspmicro certificate from the STS container's /system/security/machine_keystore.jceks and import it into the sample container's /system/security/machine_truststore.jks

6. Test the sample by logging in to web console.