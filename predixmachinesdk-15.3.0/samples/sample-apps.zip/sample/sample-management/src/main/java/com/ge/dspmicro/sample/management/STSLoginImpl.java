/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.sample.management;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.useradmin.Group;
import org.osgi.service.useradmin.Role;
import org.osgi.service.useradmin.User;
import org.osgi.service.useradmin.UserAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import aQute.bnd.annotation.component.Deactivate;
import aQute.bnd.annotation.component.Reference;

import com.ge.dspmicro.httpclient.api.HttpResponseWrapper;
import com.ge.dspmicro.httpclient.api.IHttpClient;
import com.ge.dspmicro.httpclient.api.IHttpClientFactory;
import com.prosyst.mbs.services.useradmin.Authorization;
import com.prosyst.mbs.services.useradmin.SimpleLogin;
import com.prosyst.util.encode.Base64;

/**
 * Service implementation for the Prosyst useradmin SimpleLogin API. This uses the SAML configuration from the sts configuration for
 * doing the authorization of the user. If the user is authorized, it will create a user of administration group access for the web console.
 * 
 * @author Predix Machine
 */
@Component(name = STSLoginImpl.SERVICE_PID, provide = SimpleLogin.class)
public class STSLoginImpl
        implements SimpleLogin
{
    // Logging
    private static Logger       _logger              = LoggerFactory.getLogger(STSLoginImpl.class);

    /**
     * Service PID
     */
    public final static String  SERVICE_PID          = "com.ge.dspmicro.sample.management";        //$NON-NLS-1$

    // We need to create the default user on startup. Once it exists, the user can change the password on this user or create other users.
    // The default user/password is only created if no "administration" group users exist. This is the hook to create what you want in your environment
    // and then it never creates anything again.
    private static final String ADMINISTRATION_GROUP = "administration";                           //$NON-NLS-1$

    private static final String STS_SERVER_URL       = "https://localhost:8443/sts/auth";          //$NON-NLS-1$

    private ConfigurationAdmin  configAdmin;
    private UserAdmin           userAdmin;

    // instance of HTTPClient provided by Predix Machine
    private IHttpClientFactory  httpClientFactory;
    private IHttpClient         httpClient;

    /**
     * OSGi component lifecycle activation method
     * 
     * @param ctx component context
     * @throws Exception On failure to initialize the service correctly.
     */
    @SuppressWarnings("deprecation")
    @Activate
    public void activate(ComponentContext ctx)
            throws Exception
    {
        this.httpClient.setAllowSSL(IHttpClient.sslType.ALLOW_DEFAULT_CERTS,
                SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER); // WARNING: Use BROWSER_COMPATIBLE_HOSTNAME_VERIFIER in production, disabling hostname
                                                                         // verification is for testing only!!!

        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Authentication Service Started"); //$NON-NLS-1$
        }
    }

    /**
     * OSGi component lifecycle deactivation method
     * 
     * @param ctx component context
     */
    @Deactivate
    public void deactivate(ComponentContext ctx)
    {
        // clean up service
        if ( (this.httpClient != null) && (this.httpClientFactory != null) )
        {
            this.httpClientFactory.deleteHttpClient(this.httpClient);
            this.httpClient = null;
            this.httpClientFactory = null;
        }
        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Authentication Service Stopped"); //$NON-NLS-1$
        }
    }

    /*
     * (non-Javadoc)
     * @see com.prosyst.mbs.services.useradmin.SimpleLogin#login(java.lang.String, java.lang.String)
     */
    @Override
    public Authorization login(String username, String password)
            throws Exception
    {
        boolean bAuth = isSamlAuth(username, password);
        if ( bAuth )
        {
            // This will create the user if it doesn't exist in the administrative group.
            // You could write your own authorization module to produce groups and roles here.
            // See the OSGi org.osgi.service.useradmin.UserAdmin interfaces.
            User user = createUser(username);

            if ( user != null )
            {
                _logger.info("User " + username + " successfully logged in."); //$NON-NLS-1$ //$NON-NLS-2$
                return new AuthorizationImpl(this.userAdmin.getAuthorization(user));
            }
        }

        _logger.info("Login failed."); //$NON-NLS-1$
        throw new Exception("Not Authorized"); //$NON-NLS-1$
    }


    /* (non-Javadoc)
     * @see com.prosyst.mbs.services.useradmin.SimpleLogin#login(java.lang.String, java.lang.String, java.lang.Object)
     */
    @Override
    public Authorization login(String username, String algorithm, Object credential)
            throws Exception
    {
        _logger.error("login credential not supported."); //$NON-NLS-1$
        throw new Exception("Not Authorized"); //$NON-NLS-1$
    }

    /*
     * (non-Javadoc)
     * @see com.prosyst.mbs.services.useradmin.SimpleLogin#createCredential(org.osgi.service.useradmin.User, java.lang.String)
     */
    @Override
    public void createCredential(User user, String password)
    {
        _logger.error("Create credential not supported."); //$NON-NLS-1$
        throw new IllegalArgumentException("Create credential not supported."); //$NON-NLS-1$
    }

    /* (non-Javadoc)
     * @see com.prosyst.mbs.services.useradmin.SimpleLogin#setAuthorization(java.lang.Object, com.prosyst.mbs.services.useradmin.Authorization)
     */
    @Override
    public Authorization setAuthorization(Object context, Authorization auth)
    {
        // Not used by GE Container.
        return null;
    }

    /* (non-Javadoc)
     * @see com.prosyst.mbs.services.useradmin.SimpleLogin#getAuthorization(java.lang.Object)
     */
    @Override
    public Authorization getAuthorization(Object context)
    {
        // Not used by GE Container.
        return null;
    }
    // Creates the user if it doesn't exist.
    private User createUser(String username)
            throws Exception
    {
        Group administration = (Group) this.userAdmin.getRole(ADMINISTRATION_GROUP);

        try
        {
            Role role = this.userAdmin.getRole(username);
            if ( role == null )
            {
                User user = (User) this.userAdmin.createRole(username, Role.USER);
                if ( user != null )
                {
                    administration = (Group) this.userAdmin.getRole(ADMINISTRATION_GROUP);
                    if ( administration == null )
                    {
                        administration = (Group) this.userAdmin.createRole(ADMINISTRATION_GROUP, Role.GROUP);
                    }
                    administration.addMember(user);

                    _logger.info("Administrative user " + username + " successfully created."); //$NON-NLS-1$ //$NON-NLS-2$
                }
                return user;
            }
            return (User) role;
        }
        catch (Exception ee)
        {
            _logger.error("Failed to create the administrative user " + username + ".", ee); //$NON-NLS-1$ //$NON-NLS-2$
            throw ee;
        }
    }

    //
    // Check with the configured SAML server if the user/password are authenticated.
    //
    private boolean isSamlAuth(String username, String password)
    {
        try
        {
            HttpEntity entity = createPostBody(username, password);

            Header[] headers =
            {
                    new BasicHeader(HttpHeaders.ACCEPT_ENCODING, ContentType.APPLICATION_JSON.getMimeType()),
                    new BasicHeader(HttpHeaders.CONTENT_TYPE, ContentType.APPLICATION_FORM_URLENCODED.getMimeType()),
            };
            HttpResponseWrapper response = this.httpClient.post(createRSTURL(), entity, headers);
            if ( response.getStatusCode() == HttpStatus.SC_OK )
            {
                return true;
            }
            _logger.error("isSamlAuth failed with httpcode: " + response.getStatusCode()); //$NON-NLS-1$
        }
        catch (Exception ee)
        {
            _logger.error("isSamlAuth failed.", ee);    //$NON-NLS-1$
        }
        return false;
    }

    /*
     * Create post body contents which will go into a StringEntity.
     */
    private HttpEntity createPostBody(String username, String password)
            throws UnsupportedEncodingException
    {
        List<NameValuePair> form = new ArrayList<>();
        form.add(new BasicNameValuePair(OAuthConstants.GRANT_TYPE, OAuthConstants.RESOURCE_OWNER_GRANT));
        form.add(new BasicNameValuePair(OAuthConstants.RESOURCE_OWNER_NAME, URLEncoder.encode(username, "UTF-8"))); //$NON-NLS-1$
        form.add(new BasicNameValuePair(OAuthConstants.RESOURCE_OWNER_PASSWORD, new String(Base64.encode(password
                .getBytes()))));

        return new UrlEncodedFormEntity(form);
    }

    // construct URL for STS service entpoint using values from the configuration file
    private URI createRSTURL()
    {
        URI uri = null;
        try
        {
            uri = new URI(new URL(STS_SERVER_URL).toString());
        }
        catch (MalformedURLException | URISyntaxException ee)
        {
            _logger.error("createRSTURL failed.", ee); //$NON-NLS-1$
        }
        return uri;
    }

    /**
     * Dependency injection of UserAdmin OSGi registered service.
     * 
     * @param userAdmin OSGi registered implementation of UserAdmin interface.
     */
    @Reference
    public void setUserAdmin(UserAdmin userAdmin)
    {
        this.userAdmin = userAdmin;
    }

    /**
     * clear the Dependency injection of UserAdmin
     * 
     * @param userAdmin the userAdmin to clear
     */
    public void unsetUserAdmin(@SuppressWarnings("hiding") UserAdmin userAdmin)
    {
        this.userAdmin = null;
    }

    /**
     * Setter for httpclientFactory instance. Service provided by Predix Machine
     * 
     * @param httpClientFactory the HttpClient to set
     * @throws IOException on failure.
     */
    @Reference
    public void setHttpClientFactory(IHttpClientFactory httpClientFactory)
    {
        this.httpClientFactory = httpClientFactory;
        this.httpClient = this.httpClientFactory.createHttpClient();

        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Set HTTP Client"); //$NON-NLS-1$
        }
    }

    /**
     * clear the HttpClientFactory
     * 
     * @param httpClientFactory the HttpClient to clear.
     */
    public void unsetHttpClientFactory(@SuppressWarnings("hiding") IHttpClientFactory httpClientFactory)
    {
        if ( httpClientFactory == this.httpClientFactory )
        {
            if ( this.httpClient != null )
            {
                this.httpClientFactory.deleteHttpClient(this.httpClient);
                this.httpClient = null;
            }
            this.httpClientFactory = null;
        }
    }

    /**
     * Dependency injection of ConfigurationAdmin OSGi registered service.
     * 
     * @param configAdmin
     *            OSGi registered implementation of ConfigurationAdmin interface.
     */
    @Reference
    public void setConfigAdmin(ConfigurationAdmin configAdmin)
    {
        this.configAdmin = configAdmin;
    }

    /**
     * clear the Dependency injection of TestNgRunner
     * 
     * @param configAdmin
     *            the ConfigurationAdmin to clear
     */
    public void unsetConfigAdmin(@SuppressWarnings("hiding") ConfigurationAdmin configAdmin)
    {
        if ( this.configAdmin == configAdmin )
        {
            this.configAdmin = null;
        }
    }
}
