/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.sample.management;

import org.osgi.service.useradmin.Authorization;

/**
 * Implementation of com.prosyst.mbs.services.useradmin.Authorization which wraps org.osgi.service.useradmin.Authorization in com.prosyst.mbs namespace.
 * 
 * @author Predix Machine
 */
public class AuthorizationImpl
        implements com.prosyst.mbs.services.useradmin.Authorization
{

    private final Authorization auth;

    /**
     * @param authorization Pass in Authorization
     */
    public AuthorizationImpl(Authorization authorization)
    {
        this.auth = authorization;
    }

    /*
     * (non-Javadoc)
     * @see org.osgi.service.useradmin.Authorization#getName()
     */
    @Override
    public String getName()
    {
        return this.auth.getName();
    }

    /*
     * (non-Javadoc)
     * @see org.osgi.service.useradmin.Authorization#hasRole(java.lang.String)
     */
    @Override
    public boolean hasRole(String name)
    {
        return this.auth.hasRole(name);
    }

    /*
     * (non-Javadoc)
     * @see org.osgi.service.useradmin.Authorization#getRoles()
     */
    @Override
    public String[] getRoles()
    {
        return this.auth.getRoles();
    }

    /* (non-Javadoc)
     * @see com.prosyst.mbs.services.useradmin.Authorization#logout()
     */
    @Override
    public void logout()
    {
        // No op
    }

}
