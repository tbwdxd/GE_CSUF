

Data River Send sample -- demonstrates how to use DataRiver Send service to send a file to a listening DataRiver Receive service.

Execution process of the sample:
  - The sample looks up DataRiver Send service(s) named "Sender Service" in Predix Machine
  - The sample uses the above service(s) to send a text file (sample-datariver-send.txt) embedded in its jar
  - The DataRiver Receive service receives the file and writes it to <Predix-Machine>/appdata/transfers/downloads/ directory

Configurations for the sample:
  Default configurations should work. Make sure domain ID matches in sender and receiver configuration files:
  - <Predix-Machine>/etc/com.ge.dspnet.datariver.send-0.cfg
  - <Predix-Machine>/etc/com.ge.dspnet.datariver.receive-0.cfg