/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspnet.sample.datariver.send;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import aQute.bnd.annotation.component.Deactivate;
import aQute.bnd.annotation.component.Reference;

import com.ge.dspnet.datariver.common.api.IDataRiverStatusCallback;
import com.ge.dspnet.datariver.common.api.TransferStatus;
import com.ge.dspnet.datariver.common.util.DataRiverCommon.SendStatusCodes;
import com.ge.dspnet.datariver.common.util.DataRiverRequest;
import com.ge.dspnet.datariver.send.api.IDataSend;
import com.ge.dspnet.datariver.send.api.IRiverSession;

/**
 * Data River Send Sample
 * 
 * @author Predix Net Data River Send Sample
 */

// @Component is use to register this component as Service in the container.

@SuppressWarnings("deprecation")
@Component(name = DataRiverSendSample.SERVICE_PID, provide = IDataRiverStatusCallback.class)
public class DataRiverSendSample
        implements IDataRiverStatusCallback, Runnable
{
    /** service id */
    protected final static String    SERVICE_PID  = "com.ge.dspnet.sample.datariver.send";             //$NON-NLS-1$

    /**
     * Create logger to report errors, warning massages, and info messages (runtime Statistics)
     */
    protected static Logger          _logger      = LoggerFactory.getLogger(DataRiverSendSample.class);
    
    /** The name of the DataRiver Send service we want to use. */
    private final static String      SENDER_RIVER    = "Sender Service"; //$NON-NLS-1$
    /** The name of the DataRiver Receive we want to send a request to. */
    private final static String      RECEIVER_RIVER  = "Receiver Service"; //$NON-NLS-1$
    /** The name of file to be sent. */
    private final static String      SEND_FILE_NAME  = "sample-datariver-send.txt"; //$NON-NLS-1$

    private ArrayList<IDataSend>     dataSendList = new ArrayList<IDataSend>();
    private ArrayList<IRiverSession> sessions     = new ArrayList<IRiverSession>();

    private InputStream              sampleFile;

    /**
     * The activate method is called when bundle is started.
     * 
     * @param ctx Component Context.
     */
    @Activate
    public void activate(ComponentContext ctx)
    {
        // You should never do too much in the activate or your service will get killed (assumed it hung)
        // Instead spawn a thread for initialization. This thread executes run() method.
        new Thread(this).start();

        // use the logger service for debugging purpose
        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Starting sample " + ctx.getBundleContext().getBundle().getSymbolicName()); //$NON-NLS-1$
        }
    }

    @Override
    public void run()
    {
        ClassLoader cl = this.getClass().getClassLoader();
        this.sampleFile = cl.getResourceAsStream(SEND_FILE_NAME);
        // Multiple senders can be configured, and we can iterate over the list, to send from each sender.
        for (IDataSend iDataSend : this.dataSendList)
        {
            _logger.info("Found river " + iDataSend.getDataRiverName()); //$NON-NLS-1$
            // We can add business logic here to see which river name we want to receive from
            if ( iDataSend.getDataRiverName().startsWith(SENDER_RIVER) )
            {
                sendData(iDataSend, this.sampleFile);
            }
        }
    }

    private void sendData(IDataSend dataSend, InputStream file)
    {
        /*
         * =========================================
         * 1. Create a Session to send requests in that session
         * 2. Create a DataRiverRequest object
         * 3. Pass the request object to IRiverSession to queue the reqeust until the DataSend service is ready to process the next request 
         * =========================================
         */
        
        IRiverSession session = dataSend.createSession();
        this.sessions.add(session);
        DataRiverRequest request = new DataRiverRequest("file", "name=" + SEND_FILE_NAME); //$NON-NLS-1$ //$NON-NLS-2$
        request.setDestinationRiverName(RECEIVER_RIVER);
        request.setStream(file);
        dataSend.send(request);
    }

    /**
     * This method is called when the bundle is stopped.
     * 
     * @param ctx Component Context
     * @throws IOException if there is an error closing file transfer stream
     */
    @Deactivate
    public void deactivate(ComponentContext ctx)
            throws IOException
    {
        // Put your clean up code here when container is shutting down
        this.dataSendList.clear();

        this.sampleFile.close();

        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Stopped sample for " + ctx.getBundleContext().getBundle().getSymbolicName()); //$NON-NLS-1$
        }
    }

    // /////////////////////////////////////////////////////////////////////////////////////////////////
    // OSGI and declarative services:
    // For single reference, method names should be:
    // setDataSend(IDataSend send) and unsetDataSend(IDataSend send).
    // First (normally only one reference)
    // @Reference
    // Pick a specific reference - use one of the properties from the cfg file. For example:
    // @Reference(target = "(com.ge.dspnet.datariver.send.river.name=SenderService)")
    // Get all the references
    // @Reference(type = '*')
    // (change method names must should be "addSender() and "removeSender()" instead of setDataSend and unsetDataSend.
    // /////////////////////////////////////////////////////////////////////////////////////////////////

    // /**
    // * @param send Send service
    // */
    // @Reference(target = "(com.ge.dspnet.datariver.send.river.name=SenderService)")
    // protected void setDataSend(IDataSend send)
    // {
    // this.dataSend = send;
    // }

    /**
     * Setter for data send service
     * 
     * @param send an instance of data river send service
     */
    @Reference(type = '+')
    public void addDataSend(IDataSend send)
    {
        if ( this.dataSendList != null )
        {
            this.dataSendList.add(send);
        }
    }

    /**
     * Setter for data send service
     * 
     * @param send an instance of data river send service
     */
    public void removeDataSend(IDataSend send)
    {
        if ( this.dataSendList != null )
        {
            this.dataSendList.remove(send);
        }
    }

    // Method gets called when there is a status change in the DataRiver Send Service for transfers with the TEST Category.
    @Override
    public void transferStatusChange(TransferStatus transferStatus)
    {
        int statusCode = transferStatus.getStatusCode();
        if (statusCode == SendStatusCodes.BADREQUEST.code ||
                statusCode == SendStatusCodes.TRANSFERNOTFOUND.code ||
                statusCode == SendStatusCodes.TRANSFERFAILED.code ||
                statusCode == SendStatusCodes.TIMERSHUTDOWN.code ||
                statusCode == SendStatusCodes.FILENOTFOUND.code ||
                statusCode == SendStatusCodes.CLOSEERROR.code ||
                statusCode == SendStatusCodes.TIMEOUT.code ||
                statusCode == SendStatusCodes.OPENFAIL.code)
        {
            _logger.error(transferStatus.toString());
        }
        else
        {
            _logger.info(transferStatus.toString());
        }
    }

    @Override
    public ContentCategory getContentCategory()
    {
        return ContentCategory.ALL;
    }
}
