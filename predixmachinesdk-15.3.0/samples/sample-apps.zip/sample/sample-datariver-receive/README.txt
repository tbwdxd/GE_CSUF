

Data River Receive sample -- demonstrates how to use DataRiver Receive service to request for a file from a sending service

Execution process of the sample:
  - The sample looks up DataRiver Receive service(s) named "Receiver Service" in Predix Machine
  - The sample uses the above service(s) to request for a text file (sample-datariver-receive.txt)
  - The DataRiver Send service receives the request and looks up the file in <Predix-Machine>/appdata/transfers/sends directory
  - The DataRiver Send service sends the text file
  - The DataRiver Receive service receives the file and writes it to <Predix-Machine>/appdata/transfers/downloads directory

Before running the sample:
    Copy the test file sample-datariver-receive.txt from <Predix-Machine>/sample-apps/sample-datariver-receive/src/main/resources
    to <Predix-Machine>/appdata/transfers/sends directory

Configurations for the sample:
  Default configurations should work. Make sure domain ID matches in sender and receiver configuration files:
  - <Predix-Machine>/etc/com.ge.dspnet.datariver.send-0.cfg
  - <Predix-Machine>/etc/com.ge.dspnet.datariver.receive-0.cfg