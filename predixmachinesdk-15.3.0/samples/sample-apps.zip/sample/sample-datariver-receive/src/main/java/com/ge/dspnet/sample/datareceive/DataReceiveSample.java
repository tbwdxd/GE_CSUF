/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspnet.sample.datareceive;

import java.io.IOException;
import java.util.ArrayList;

import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import aQute.bnd.annotation.component.Deactivate;
import aQute.bnd.annotation.component.Reference;

import com.ge.dspnet.datariver.common.api.IDataRiverStatusCallback;
import com.ge.dspnet.datariver.common.api.TransferStatus;
import com.ge.dspnet.datariver.common.util.DataRiverCommon.RecStatusCodes;
import com.ge.dspnet.datariver.common.util.DataRiverRequest;
import com.ge.dspnet.datariver.receive.api.IDataReceive;

/**
 * Data Transfer sample
 * 
 * @author Predix Net Data River Receive Sample
 */

// @Component is use to register this component as Service in the container.

@SuppressWarnings("deprecation")
@Component(name = DataReceiveSample.SERVICE_PID)
public class DataReceiveSample
        implements IDataRiverStatusCallback, Runnable

{
    /** service id */
    protected final static String   SERVICE_PID     = "com.ge.dspnet.sample.datareceive";              //$NON-NLS-1$
    
    /** The name of the DataRiver Send service we want to send a request to. */
    private final static String     SENDER_RIVER    = "Sender Service"; //$NON-NLS-1$
    /** The name of the DataRiver Receive we want to use. */
    private final static String     RECEIVER_RIVER  = "Receiver Service"; //$NON-NLS-1$
    /** The name of file to be sent. */
    private final static String     RECEIVE_FILE_NAME = "sample-datariver-receive.txt"; //$NON-NLS-1$

    // Create logger to report errors, warning massages, and info messages (runtime Statistics)
    private static Logger           _logger         = LoggerFactory.getLogger(DataReceiveSample.class);

    private ArrayList<IDataReceive> dataReceiveList = new ArrayList<IDataReceive>();

    /**
     * The activate method is called when bundle is started.
     * 
     * @param ctx Component Context.
     */
    @Activate
    public void activate(ComponentContext ctx)
    {
        // You should never do too much in the activate or your service will get killed (assumed it hung)
        // Instead spawn a thread for initialization.
        new Thread(this).start();

        // use the logger service for debugging purpose
        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Starting sample " + ctx.getBundleContext().getBundle().getSymbolicName()); //$NON-NLS-1$
        }
    }

    @Override
    public void run()
    {
        // Ask for file.
        // any file should be saved in the <container>/appdata/transfers/sends directory
        // This location can be configured in the com.ge.dspnet.datariver.send-0.cfg file.
        // Multiple receivers can be configured, and we can iterate over the list, to receive from each sender.

        for (IDataReceive iDataReceive : this.dataReceiveList)
        {
            // We can add business logic here to see which river name we want to receive from
            if ( iDataReceive.getDataRiverName().startsWith(RECEIVER_RIVER) )
            {
                receiveData(iDataReceive, RECEIVE_FILE_NAME);
            }
        }
    }

    /**
     * This method creates a request to send to the Data River Send method to request for a file
     * 
     * @param dataReceive The receiver name
     * 
     * 
     * @param fileName Name of the file to request
     */
    protected void receiveData(IDataReceive dataReceive, String fileName)
    {
        /*
         * =========================================
         * 1. Create a DataRiverRequest object
         * 2. Pass the request object to the IDataReceive service
         * =========================================
         */

        // Specify the name of the file you are requesting in the content disposition with a  key value pair.
        DataRiverRequest request = new DataRiverRequest("file", "name=" + fileName); //$NON-NLS-1$ //$NON-NLS-2$
        request.setDestinationRiverName(SENDER_RIVER);
        dataReceive.receive(request);
    }

    /**
     * This method is called when the bundle is stopped.
     * 
     * @param ctx Component Context
     * @throws IOException if there is an error closing file transfer stream
     */
    @Deactivate
    public void deactivate(ComponentContext ctx)
            throws IOException
    {
        // Put your clean up code here when container is shutting down
        this.dataReceiveList.clear();

        if ( _logger.isDebugEnabled() )
        {
            _logger.debug("Stopped sample for " + ctx.getBundleContext().getBundle().getSymbolicName()); //$NON-NLS-1$
        }
    }

    // /////////////////////////////////////////////////////////////////////////////////////////////////
    // OSGI and declarative services:
    // For single reference, method names should be:
    // setDataReceive(IDataReceive receive) and unsetDataReceive(IDataReceive receive).
    // First (normally only one reference)
    // @Reference
    // Pick a specific reference - use one of the properties from the cfg file. For example:
    // @Reference(target = "(com.ge.dspnet.datariver.receive.river.name=ReceiverService)")
    // Get all the references
    // @Reference(type = '*')
    // (change method names must should be "addReceiver() and "removeReceiver()" instead of setDataReceive and unsetDataReceive.
    // /////////////////////////////////////////////////////////////////////////////////////////////////

    // /**
    // * @param receive Receiver service
    // */
    // @Reference(target = "(com.ge.dspnet.datariver.receive.river.name=ReceiverService)")
    // protected void setDataReceive(IDataReceive receive)
    // {
    // this.dataReceive = receive;
    // }

    /**
     * Setter for data receive service
     * 
     * @param receive an instance of data transfer receive service
     */
    @Reference(type = '+')
    public void addDataReceive(IDataReceive receive)
    {
        if (this.dataReceiveList != null)
        {
            this.dataReceiveList.add(receive);
        }
    }

    /**
     * Setter for data receive service
     * 
     * @param receive an instance of data transfer receive service
     */
    public void removeDataReceive(IDataReceive receive)
    {
        if (this.dataReceiveList != null)
        {
            this.dataReceiveList.remove(receive);
        }
    }

    @Override
    public void transferStatusChange(TransferStatus transferStatus)
    {
        int statusCode = transferStatus.getStatusCode();
        if (statusCode == RecStatusCodes.FILENOTFOUND.code ||
                statusCode == RecStatusCodes.TRANSFERFAILED.code ||
                statusCode == RecStatusCodes.TRANSFERNOTFOUND.code ||
                statusCode == RecStatusCodes.TIMEOUT.code)
        {
            _logger.error(transferStatus.toString());
        }
        else
        {
            _logger.info(transferStatus.toString());
        }
    }

    @Override
    public ContentCategory getContentCategory()
    {
        return ContentCategory.ALL;
    }
}
