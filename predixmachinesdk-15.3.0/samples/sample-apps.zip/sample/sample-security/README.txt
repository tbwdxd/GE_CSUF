

Security Sample - Shows how to use the SecurityAdmin service to encrypt and decrypt a string containing senstaive information.

This Sample Requires Configuration of keystores environment.
	Copy security configuration and keystores files, com.ge.dspmicro.securityadmin.cfg & 
	dspmicro_truststore.jks 
		From		<Predix-Machine>/sample-apps/system/security
		to 			<Predix-Machine>/system/security
