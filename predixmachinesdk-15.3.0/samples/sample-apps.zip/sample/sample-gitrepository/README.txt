

Git Repository Sample - facilitates the use of JGit.

gitrepository service creates a repository automatically based on 
the com.ge.dspmicro.gitrepository.cfg configurations in the <Predix-Machine>/etc/ folder 

This Sample uses the local repoistory created from the gitrepository service and 
shows how to remove files, remove changes, update local repository, and incorporate changes
to the remote repository.
